declare module 'dnscache';
